import { useState, useCallback, useEffect } from "react";
import { Product, CartItem } from "./data";
import Header from "./components/Header";
import Hero from "./components/Hero";
import Categories from "./components/Categories";
import BestSellers from "./components/BestSellers";
import ProductDetail from "./components/ProductDetail";
import CartDrawer from "./components/CartDrawer";
import AIAssistant from "./components/AIAssistant";
import RoutineBuilder from "./components/RoutineBuilder";
import NewArrivals from "./components/NewArrivals";
import HomePage from "./components/HomePage";
import ShopPage from "./components/ShopPage";
import Checkout from "./components/Checkout";
import Footer from "./components/Footer";
import DeviceToggle from "./components/DeviceToggle";

type Page = "home" | "shop" | "product" | "checkout";
type Device = "desktop" | "mobile";

export default function App() {
  const [page, setPage] = useState<Page>("home");
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [shopCategory, setShopCategory] = useState("all");
  const [cart, setCart] = useState<CartItem[]>([]);
  const [wishlist, setWishlist] = useState<number[]>([]);
  const [cartOpen, setCartOpen] = useState(false);
  const [device, setDevice] = useState<Device>("desktop");
  const [pendingScroll, setPendingScroll] = useState<string | null>(null);

  const navigate = useCallback(
    (target: string, product?: Product, category?: string, scrollTo?: string) => {
      if (target === "product" && product) {
        setSelectedProduct(product);
        setPage("product");
        window.scrollTo({ top: 0, behavior: "smooth" });
      } else if (target === "shop") {
        setShopCategory(category || "all");
        setPage("shop");
        window.scrollTo({ top: 0, behavior: "smooth" });
      } else if (target === "checkout") {
        setPage("checkout");
        window.scrollTo({ top: 0, behavior: "smooth" });
      } else {
        setPage("home");
        if (scrollTo) {
          // Defer to an effect so the scroll runs after the home page renders,
          // even when we are already on the home page.
          setPendingScroll(scrollTo);
        } else {
          window.scrollTo({ top: 0, behavior: "smooth" });
        }
      }
    },
    []
  );

  // Perform a pending in-page scroll once the home page is on screen. Retries a
  // few frames in case the target section has not mounted yet.
  useEffect(() => {
    if (page !== "home" || !pendingScroll) return;
    let attempts = 0;
    let raf = 0;
    const tryScroll = () => {
      const el = document.getElementById(pendingScroll);
      if (el) {
        el.scrollIntoView({ behavior: "smooth", block: "start" });
        setPendingScroll(null);
        return;
      }
      if (attempts++ < 20) {
        raf = requestAnimationFrame(tryScroll);
      } else {
        setPendingScroll(null);
      }
    };
    raf = requestAnimationFrame(tryScroll);
    return () => cancelAnimationFrame(raf);
  }, [page, pendingScroll]);

  const addToCart = useCallback((product: Product, qty = 1) => {
    setCart((prev) => {
      const existing = prev.find((i) => i.product.id === product.id);
      if (existing) {
        return prev.map((i) =>
          i.product.id === product.id ? { ...i, quantity: i.quantity + qty } : i
        );
      }
      return [...prev, { product, quantity: qty }];
    });
    setCartOpen(true);
  }, []);

  const removeFromCart = useCallback((id: number) => {
    setCart((prev) => prev.filter((i) => i.product.id !== id));
  }, []);

  const updateCartQty = useCallback((id: number, qty: number) => {
    setCart((prev) =>
      prev.map((i) => (i.product.id === id ? { ...i, quantity: qty } : i))
    );
  }, []);

  const toggleWishlist = useCallback((id: number) => {
    setWishlist((prev) =>
      prev.includes(id) ? prev.filter((w) => w !== id) : [...prev, id]
    );
  }, []);

  const cartCount = cart.reduce((sum, i) => sum + i.quantity, 0);

  const handleSuccess = () => {
    setCart([]);
  };

  return (
    <div className={`min-h-screen bg-warm font-sans ${device === "mobile" ? "py-6" : ""}`}>
      <div className={`device-stage ${device === "mobile" ? "is-mobile" : ""}`}>
      <div className={`device-scroll min-h-screen bg-ivory ${device === "mobile" ? "device-mobile-scope" : ""}`}>
      {page !== "checkout" && (
        <Header
          onNavigate={navigate}
          cartCount={cartCount}
          wishlistCount={wishlist.length}
          onCartOpen={() => setCartOpen(true)}
          currentPage={page}
          productName={selectedProduct?.name}
        />
      )}

      <CartDrawer
        isOpen={cartOpen}
        onClose={() => setCartOpen(false)}
        items={cart}
        onRemove={removeFromCart}
        onUpdateQty={updateCartQty}
        onCheckout={() => navigate("checkout")}
      />

      {page === "home" && (
        <>
          <Hero onNavigate={navigate} />
          <Categories onNavigate={navigate} />
          <BestSellers
            onView={(p) => navigate("product", p)}
            onAddToCart={addToCart}
            wishlist={wishlist}
            onWishlist={toggleWishlist}
            onNavigate={navigate}
          />
          <AIAssistant
            onAddToCart={addToCart}
            onView={(p) => navigate("product", p)}
          />
          <RoutineBuilder onAddToCart={addToCart} />
          <NewArrivals
            onView={(p) => navigate("product", p)}
            onAddToCart={addToCart}
            wishlist={wishlist}
            onWishlist={toggleWishlist}
            onNavigate={navigate}
          />
          <HomePage onNavigate={navigate} />
          <Footer onNavigate={navigate} />
        </>
      )}

      {page === "shop" && (
        <>
          <ShopPage
            initialCategory={shopCategory}
            onView={(p) => navigate("product", p)}
            onAddToCart={addToCart}
            wishlist={wishlist}
            onWishlist={toggleWishlist}
            onNavigate={navigate}
          />
          <Footer onNavigate={navigate} />
        </>
      )}

      {page === "product" && selectedProduct && (
        <>
          <ProductDetail
            product={selectedProduct}
            onAddToCart={addToCart}
            isWishlisted={wishlist.includes(selectedProduct.id)}
            onWishlist={toggleWishlist}
            onNavigate={navigate}
          />
          <Footer onNavigate={navigate} />
        </>
      )}

      {page === "checkout" && (
        <Checkout
          items={cart}
          onBack={() => navigate("home")}
          onSuccess={handleSuccess}
        />
      )}

      {/* Mobile sticky cart */}
      {page !== "checkout" && cartCount > 0 && (
        <div
          className={`${device === "mobile" ? "absolute" : "fixed lg:hidden"} bottom-0 left-0 right-0 z-30 p-4 bg-ivory border-t border-linen`}
        >
          <button
            onClick={() => setCartOpen(true)}
            className="w-full bg-charcoal text-ivory py-4 text-sm tracking-widest uppercase font-sans flex items-center justify-center gap-3"
          >
            <span>View Bag</span>
            <span className="bg-bronze w-6 h-6 rounded-full text-xs flex items-center justify-center">
              {cartCount}
            </span>
            <span>· ₹{cart.reduce((s, i) => s + i.product.price * i.quantity, 0)}</span>
          </button>
        </div>
      )}
      </div>
      </div>

      <DeviceToggle device={device} onChange={setDevice} />
    </div>
  );
}
