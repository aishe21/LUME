import { useState } from "react";
import { Product, products } from "../data";

interface HeaderProps {
  onNavigate: (page: string, product?: Product, category?: string, scrollTo?: string) => void;
  cartCount: number;
  wishlistCount: number;
  onCartOpen: () => void;
  currentPage?: string;
  productName?: string;
}

const nav: { label: string; page: string; cat?: string; scrollTo?: string }[] = [
  { label: "Shop", page: "shop", cat: "all" },
  { label: "Skincare", page: "shop", cat: "skincare" },
  { label: "Bath & Body", page: "shop", cat: "body" },
  { label: "Soaps", page: "shop", cat: "soaps" },
  { label: "Best Sellers", page: "home", scrollTo: "best-sellers" },
  { label: "New Arrivals", page: "home", scrollTo: "new-arrivals" },
  { label: "About Us", page: "home", scrollTo: "about" },
];

// Announcement bar content + accent switches with the active page/content.
function getAnnouncement(page: string, productName?: string) {
  switch (page) {
    case "shop":
      return {
        text: "Explore the full ritual · Complimentary samples with every order",
        bg: "bg-sage-deep",
        fg: "text-ivory",
      };
    case "product":
      return {
        text: productName
          ? `${productName} · Cruelty-free & dermatologist tested`
          : "Clean formulas · Cruelty-free & dermatologist tested",
        bg: "bg-clay",
        fg: "text-ivory",
      };
    case "checkout":
      return {
        text: "Secure checkout · 100% encrypted payment · Easy 30-day returns",
        bg: "bg-bronze-dark",
        fg: "text-ivory",
      };
    default:
      return {
        text: "Free shipping over ₹999 · New Year Ritual: 15% off with code LUME2026",
        bg: "bg-charcoal",
        fg: "text-ivory",
      };
  }
}

export default function Header({ onNavigate, cartCount, wishlistCount, onCartOpen, currentPage = "home", productName }: HeaderProps) {
  const [mobileOpen, setMobileOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");

  const announcement = getAnnouncement(currentPage, productName);

  const searchResults = searchQuery.length > 1
    ? products.filter((p) =>
        p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        p.shortDesc.toLowerCase().includes(searchQuery.toLowerCase())
      ).slice(0, 5)
    : [];

  return (
    <>
      {/* Announcement Bar — content & accent switch with the active page */}
      <div
        className={`${announcement.bg} ${announcement.fg} text-xs tracking-widest uppercase text-center py-2.5 font-sans transition-colors duration-300`}
      >
        {announcement.text}
      </div>

      {/* Main Header */}
      <header className="sticky top-0 z-50 bg-ivory border-b border-linen">
        <div className="max-w-7xl mx-auto px-6 lg:px-8 flex items-center justify-between h-16 lg:h-20">
          {/* Mobile Menu Toggle */}
          <button
            className="lg:hidden text-charcoal"
            onClick={() => setMobileOpen(!mobileOpen)}
            aria-label="Toggle menu"
          >
            <svg width="22" height="22" fill="none" stroke="currentColor" strokeWidth="1.5" viewBox="0 0 24 24">
              {mobileOpen
                ? <path strokeLinecap="round" d="M6 18L18 6M6 6l12 12" />
                : <path strokeLinecap="round" d="M4 6h16M4 12h16M4 18h16" />}
            </svg>
          </button>

          {/* Logo */}
          <a
            href="#"
            onClick={(e) => { e.preventDefault(); onNavigate("home"); }}
            className="font-display text-2xl lg:text-3xl tracking-[0.2em] text-charcoal select-none"
          >
            LUM<span className="text-bronze">É</span>
          </a>

          {/* Desktop Nav */}
          <nav className="hidden lg:flex items-center gap-8">
            {nav.map((item) => {
              const active = currentPage === item.page && item.page === "shop";
              return (
                <button
                  key={item.label}
                  onClick={() => onNavigate(item.page, undefined, item.cat, item.scrollTo)}
                  className={`text-sm transition-colors duration-200 font-sans tracking-wide border-b-2 pb-0.5 ${
                    active
                      ? "text-bronze border-bronze"
                      : "text-charcoal border-transparent hover:text-bronze"
                  }`}
                >
                  {item.label}
                </button>
              );
            })}
          </nav>

          {/* Right Icons */}
          <div className="flex items-center gap-4 lg:gap-5">
            {/* Search */}
            <button
              onClick={() => setSearchOpen(!searchOpen)}
              className="text-charcoal hover:text-bronze transition-colors"
              aria-label="Search"
            >
              <svg width="20" height="20" fill="none" stroke="currentColor" strokeWidth="1.5" viewBox="0 0 24 24">
                <circle cx="11" cy="11" r="7" />
                <path strokeLinecap="round" d="M16.5 16.5L21 21" />
              </svg>
            </button>

            {/* Account */}
            <button className="hidden lg:block text-charcoal hover:text-bronze transition-colors" aria-label="Account">
              <svg width="20" height="20" fill="none" stroke="currentColor" strokeWidth="1.5" viewBox="0 0 24 24">
                <path strokeLinecap="round" d="M15.75 6a3.75 3.75 0 11-7.5 0 3.75 3.75 0 017.5 0zM4.501 20.118a7.5 7.5 0 0114.998 0A17.933 17.933 0 0112 21.75c-2.676 0-5.216-.584-7.499-1.632z" />
              </svg>
            </button>

            {/* Wishlist */}
            <button className="hidden lg:block relative text-charcoal hover:text-bronze transition-colors" aria-label="Wishlist">
              <svg width="20" height="20" fill="none" stroke="currentColor" strokeWidth="1.5" viewBox="0 0 24 24">
                <path strokeLinecap="round" d="M21 8.25c0-2.485-2.099-4.5-4.688-4.5-1.935 0-3.597 1.126-4.312 2.733-.715-1.607-2.377-2.733-4.313-2.733C5.1 3.75 3 5.765 3 8.25c0 7.22 9 12 9 12s9-4.78 9-12z" />
              </svg>
              {wishlistCount > 0 && (
                <span className="absolute -top-1.5 -right-1.5 bg-bronze text-ivory text-[10px] w-4 h-4 rounded-full flex items-center justify-center font-sans">
                  {wishlistCount}
                </span>
              )}
            </button>

            {/* Cart */}
            <button
              onClick={onCartOpen}
              className="relative text-charcoal hover:text-bronze transition-colors"
              aria-label="Shopping bag"
            >
              <svg width="20" height="20" fill="none" stroke="currentColor" strokeWidth="1.5" viewBox="0 0 24 24">
                <path strokeLinecap="round" d="M15.75 10.5V6a3.75 3.75 0 10-7.5 0v4.5m11.356-1.993l1.263 12c.07.665-.45 1.243-1.119 1.243H4.25a1.125 1.125 0 01-1.12-1.243l1.264-12A1.125 1.125 0 015.513 7.5h12.974c.576 0 1.059.435 1.119 1.007z" />
              </svg>
              {cartCount > 0 && (
                <span className="absolute -top-1.5 -right-1.5 bg-bronze text-ivory text-[10px] w-4 h-4 rounded-full flex items-center justify-center font-sans">
                  {cartCount}
                </span>
              )}
            </button>
          </div>
        </div>

        {/* Search Bar */}
        {searchOpen && (
          <div className="border-t border-linen bg-ivory px-6 lg:px-8 py-4 relative">
            <div className="max-w-xl mx-auto relative">
              <input
                type="text"
                placeholder="Search products..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full border border-linen rounded-none px-4 py-3 text-sm text-charcoal bg-warm font-sans placeholder-stone focus:border-bronze transition-colors"
                autoFocus
              />
              {searchResults.length > 0 && (
                <div className="absolute top-full left-0 right-0 bg-ivory border border-linen shadow-lg z-50">
                  {searchResults.map((p) => (
                    <button
                      key={p.id}
                      onClick={() => { onNavigate("product", p); setSearchOpen(false); setSearchQuery(""); }}
                      className="w-full flex items-center gap-4 px-4 py-3 hover:bg-warm transition-colors text-left"
                    >
                      <img src={p.image} alt={p.name} className="w-10 h-10 object-cover" />
                      <div>
                        <p className="text-sm font-medium text-charcoal">{p.name}</p>
                        <p className="text-xs text-stone">₹{p.price}</p>
                      </div>
                    </button>
                  ))}
                </div>
              )}
            </div>
          </div>
        )}

        {/* Mobile Menu */}
        {mobileOpen && (
          <div className="lg:hidden border-t border-linen bg-ivory px-6 py-6">
            <nav className="flex flex-col gap-5">
              {nav.map((item) => (
                <button
                  key={item.label}
                  onClick={() => { onNavigate(item.page, undefined, item.cat, item.scrollTo); setMobileOpen(false); }}
                  className="text-left text-sm text-charcoal hover:text-bronze transition-colors font-sans tracking-wide"
                >
                  {item.label}
                </button>
              ))}
            </nav>
          </div>
        )}
      </header>
    </>
  );
}
