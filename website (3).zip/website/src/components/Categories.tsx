import { categories } from "../data";

interface CategoriesProps {
  onNavigate: (page: string, product?: undefined, category?: string) => void;
}

export default function Categories({ onNavigate }: CategoriesProps) {
  return (
    <section className="py-24 px-6 lg:px-8 bg-ivory">
      <div className="max-w-7xl mx-auto">
        <div className="mb-12 flex flex-col sm:flex-row sm:items-end sm:justify-between gap-4">
          <div>
            <p className="text-xs tracking-[0.25em] uppercase text-stone font-sans mb-3">Explore</p>
            <h2 className="font-display text-4xl lg:text-5xl text-charcoal">Shop by Category</h2>
          </div>
          <button
            onClick={() => onNavigate("shop", undefined, "all")}
            className="text-sm text-bronze hover:text-charcoal transition-colors font-sans tracking-wide underline underline-offset-4 self-start sm:self-auto"
          >
            View all products →
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {categories.map((cat, i) => (
            <button
              key={cat.id}
              onClick={() => onNavigate("shop", undefined, cat.id)}
              className="group relative overflow-hidden bg-warm aspect-[3/4] text-left"
            >
              <img
                src={cat.image}
                alt={cat.name}
                className="absolute inset-0 w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-charcoal/60 via-charcoal/10 to-transparent" />
              <div className="absolute inset-0 p-6 flex flex-col justify-end">
                <h3 className="font-display text-2xl text-ivory mb-1">{cat.name}</h3>
                <p className="text-xs text-ivory/70 font-sans leading-relaxed">{cat.description}</p>
                <span className="mt-4 text-xs text-ivory/60 font-sans tracking-widest uppercase group-hover:text-sage transition-colors">
                  Shop Now →
                </span>
              </div>
              {/* Number label */}
              <div className="absolute top-5 right-5 font-display text-ivory/20 text-5xl leading-none select-none">
                0{i + 1}
              </div>
            </button>
          ))}
        </div>
      </div>
    </section>
  );
}
