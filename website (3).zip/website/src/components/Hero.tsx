interface HeroProps {
  onNavigate: (page: string, product?: undefined, category?: string) => void;
}

export default function Hero({ onNavigate }: HeroProps) {
  return (
    <section className="relative min-h-[88vh] flex items-center overflow-hidden bg-warm">
      <div className="max-w-7xl mx-auto w-full px-6 lg:px-8 grid lg:grid-cols-2 gap-12 lg:gap-0 items-center py-20 lg:py-0">
        {/* Left: Text */}
        <div className="flex flex-col gap-6 lg:gap-8 lg:pr-16 z-10">
          <p className="text-xs tracking-[0.25em] uppercase text-olive font-sans">
            Clean · Thoughtful · Modern
          </p>
          <h1 className="font-display text-5xl sm:text-6xl lg:text-7xl text-charcoal leading-[1.05]">
            Simple<br />
            <em>Rituals.</em><br />
            Better Skin.
          </h1>
          <p className="text-base lg:text-lg text-stone font-sans leading-relaxed max-w-md">
            Thoughtfully crafted skincare and body essentials, made with clean, science-backed ingredients for your everyday ritual.
          </p>
          <div className="flex flex-wrap gap-4 pt-2">
            <button
              onClick={() => onNavigate("shop", undefined, "all")}
              className="bg-olive text-ivory px-8 py-4 text-sm tracking-widest uppercase font-sans hover:bg-charcoal transition-colors duration-300"
            >
              Shop Best Sellers
            </button>
            <button
              onClick={() => onNavigate("shop", undefined, "skincare")}
              className="border border-olive text-olive px-8 py-4 text-sm tracking-widest uppercase font-sans hover:bg-olive hover:text-ivory transition-colors duration-300"
            >
              Explore Skincare
            </button>
          </div>
          <div className="flex items-center gap-8 pt-4 border-t border-linen">
            <div>
              <p className="font-display text-2xl text-olive">48k+</p>
              <p className="text-xs text-stone font-sans tracking-wide">Happy customers</p>
            </div>
            <div className="w-px h-8 bg-sage" />
            <div>
              <p className="font-display text-2xl text-olive">4.8★</p>
              <p className="text-xs text-stone font-sans tracking-wide">Avg. rating</p>
            </div>
            <div className="w-px h-8 bg-sage" />
            <div>
              <p className="font-display text-2xl text-olive">100%</p>
              <p className="text-xs text-stone font-sans tracking-wide">Clean &amp; vegan</p>
            </div>
          </div>
        </div>

        {/* Right: Image */}
        <div className="relative h-[460px] lg:h-full lg:min-h-[88vh] bg-petal overflow-hidden">
          <img
            src="https://images.unsplash.com/photo-1748543668676-ea8241cb3886?w=900&h=1200&fit=crop&auto=format"
            alt="Luxury skincare products arranged on a minimal stone background"
            className="w-full h-full object-cover object-center"
          />
          {/* Editorial overlay badge */}
          <div className="absolute bottom-8 left-8 bg-ivory/90 backdrop-blur-sm px-5 py-4 max-w-[180px] border-l-2 border-olive">
            <p className="text-xs tracking-widest uppercase text-olive font-sans mb-1">SS 2026 Edit</p>
            <p className="font-display text-charcoal text-base leading-snug">Ritual Essentials</p>
          </div>
        </div>
      </div>

      {/* Decorative corner mark */}
      <div className="absolute top-8 left-8 hidden lg:block">
        <div className="w-12 h-12 border-l border-t border-olive opacity-50" />
      </div>
      <div className="absolute bottom-8 right-8 hidden lg:block">
        <div className="w-12 h-12 border-r border-b border-olive opacity-50" />
      </div>
    </section>
  );
}
