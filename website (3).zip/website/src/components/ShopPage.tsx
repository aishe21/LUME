import { useState, useMemo, useEffect } from "react";
import { products, categories, Product } from "../data";
import ProductCard from "./ProductCard";

interface ShopPageProps {
  initialCategory?: string;
  onView: (product: Product) => void;
  onAddToCart: (product: Product) => void;
  wishlist: number[];
  onWishlist: (id: number) => void;
  onNavigate: (page: string, product?: Product, category?: string) => void;
}

type SortOption = "popular" | "price-asc" | "price-desc" | "newest";

export default function ShopPage({ initialCategory = "all", onView, onAddToCart, wishlist, onWishlist, onNavigate }: ShopPageProps) {
  const [activeCategory, setActiveCategory] = useState(initialCategory);
  const [sort, setSort] = useState<SortOption>("popular");
  const [maxPrice, setMaxPrice] = useState(2000);
  const [filtersOpen, setFiltersOpen] = useState(false);

  // Sync the active category when navigation requests a new one while the Shop
  // page is already mounted (e.g. clicking Skincare in the header from Shop).
  useEffect(() => {
    setActiveCategory(initialCategory);
  }, [initialCategory]);

  const catLabel: Record<string, string> = {
    all: "All Products",
    skincare: "Skincare",
    body: "Bath & Body",
    soaps: "Soaps",
    hair: "Hair Care",
  };

  const filtered = useMemo(() => {
    let list = activeCategory === "all" ? products : products.filter((p) => p.category === activeCategory);
    list = list.filter((p) => p.price <= maxPrice);
    if (sort === "price-asc") list = [...list].sort((a, b) => a.price - b.price);
    else if (sort === "price-desc") list = [...list].sort((a, b) => b.price - a.price);
    else if (sort === "newest") list = [...list].filter((p) => p.isNew).concat(list.filter((p) => !p.isNew));
    else list = [...list].sort((a, b) => b.reviewCount - a.reviewCount);
    return list;
  }, [activeCategory, sort, maxPrice]);

  return (
    <div className="min-h-screen bg-ivory">
      {/* Shop Header */}
      <div className="bg-warm border-b border-linen py-7 px-6 lg:px-8 text-center">
        <p className="text-xs tracking-[0.25em] uppercase text-stone font-sans mb-1.5">LUMÉ</p>
        <h1 className="font-display text-3xl lg:text-4xl text-charcoal">{catLabel[activeCategory] || "Shop"}</h1>
      </div>

      <div className="max-w-7xl mx-auto px-6 lg:px-8 pt-6 pb-10">
        {/* Filters Bar */}
        <div className="flex flex-wrap items-center gap-4 mb-8">
          {/* Category Tabs */}
          <div className="flex flex-wrap gap-2">
            {Object.entries(catLabel).map(([key, label]) => (
              <button
                key={key}
                onClick={() => setActiveCategory(key)}
                className={`px-4 py-2 text-xs tracking-widest uppercase font-sans border transition-all ${activeCategory === key ? "bg-stone text-ivory border-stone" : "border-linen text-stone hover:border-stone hover:text-charcoal hover:bg-petal"}`}
              >
                {label}
              </button>
            ))}
          </div>

          {/* Sort + Filters Right */}
          <div className="ml-auto flex items-center gap-3">
            <button
              onClick={() => setFiltersOpen(!filtersOpen)}
              className="flex items-center gap-2 text-xs tracking-widest uppercase text-stone hover:text-charcoal font-sans border border-linen px-4 py-2"
            >
              <svg width="14" height="14" fill="none" stroke="currentColor" strokeWidth="1.5" viewBox="0 0 24 24">
                <path strokeLinecap="round" d="M10.5 6h9.75M10.5 6a1.5 1.5 0 11-3 0m3 0a1.5 1.5 0 10-3 0M3.75 6H7.5m3 12h9.75m-9.75 0a1.5 1.5 0 01-3 0m3 0a1.5 1.5 0 00-3 0m-3.75 0H7.5m9-6h3.75m-3.75 0a1.5 1.5 0 01-3 0m3 0a1.5 1.5 0 00-3 0m-9.75 0h9.75" />
              </svg>
              Filters
            </button>
            <select
              value={sort}
              onChange={(e) => setSort(e.target.value as SortOption)}
              className="text-xs font-sans text-charcoal bg-ivory border border-linen px-4 py-2 tracking-wide"
            >
              <option value="popular">Sort: Popular</option>
              <option value="newest">Sort: Newest</option>
              <option value="price-asc">Price: Low to High</option>
              <option value="price-desc">Price: High to Low</option>
            </select>
          </div>
        </div>

        {/* Price Filter Panel */}
        {filtersOpen && (
          <div className="mb-8 p-6 bg-petal border border-linen flex flex-wrap gap-8 items-center">
            <div className="flex flex-col gap-2">
              <label className="text-xs uppercase tracking-widest text-stone font-sans">Max Price: ₹{maxPrice}</label>
              <input
                type="range"
                min={100}
                max={2000}
                step={50}
                value={maxPrice}
                onChange={(e) => setMaxPrice(Number(e.target.value))}
                className="w-48 accent-stone"
              />
              <div className="flex justify-between text-xs text-stone font-sans">
                <span>₹100</span>
                <span>₹2000</span>
              </div>
            </div>
            <div className="flex flex-col gap-2">
              <p className="text-xs uppercase tracking-widest text-stone font-sans">Category</p>
              <div className="flex flex-col gap-1.5">
                {categories.map((cat) => (
                  <label key={cat.id} className="flex items-center gap-2 text-sm font-sans text-charcoal cursor-pointer">
                    <input
                      type="radio"
                      name="cat"
                      checked={activeCategory === cat.id}
                      onChange={() => setActiveCategory(cat.id)}
                      className="accent-stone"
                    />
                    {cat.name}
                  </label>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* Results count */}
        <p className="text-xs text-stone font-sans mb-6 uppercase tracking-widest">
          {filtered.length} products
        </p>

        {/* Product Grid */}
        {filtered.length > 0 ? (
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-5 lg:gap-8">
            {filtered.map((product) => (
              <ProductCard
                key={product.id}
                product={product}
                onView={onView}
                onAddToCart={onAddToCart}
                isWishlisted={wishlist.includes(product.id)}
                onWishlist={onWishlist}
              />
            ))}
          </div>
        ) : (
          <div className="text-center py-24">
            <p className="font-display text-2xl text-stone mb-4">No products found</p>
            <button onClick={() => { setMaxPrice(2000); setActiveCategory("all"); }} className="text-sm text-bronze font-sans underline underline-offset-4">
              Clear filters
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
