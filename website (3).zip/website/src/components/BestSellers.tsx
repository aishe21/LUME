import { bestSellers, Product } from "../data";
import ProductCard from "./ProductCard";

interface BestSellersProps {
  onView: (product: Product) => void;
  onAddToCart: (product: Product) => void;
  wishlist: number[];
  onWishlist: (id: number) => void;
  onNavigate: (page: string) => void;
}

export default function BestSellers({ onView, onAddToCart, wishlist, onWishlist, onNavigate }: BestSellersProps) {
  return (
    <section id="best-sellers" className="pt-14 pb-24 px-6 lg:px-8 bg-ivory scroll-mt-16 lg:scroll-mt-20">
      <div className="max-w-7xl mx-auto">
        <div className="mb-12 flex flex-col sm:flex-row sm:items-end sm:justify-between gap-4">
          <div>
            <p className="text-xs tracking-[0.25em] uppercase text-stone font-sans mb-3">
              Most Loved
            </p>
            <h2 className="font-display text-4xl lg:text-5xl text-charcoal">Best Sellers</h2>
          </div>
          <button
            onClick={() => onNavigate("shop")}
            className="text-sm text-bronze hover:text-charcoal transition-colors font-sans tracking-wide underline underline-offset-4 self-start sm:self-auto"
          >
            Shop all products →
          </button>
        </div>

        <div className="grid grid-cols-2 lg:grid-cols-4 gap-5 lg:gap-8">
          {bestSellers.slice(0, 8).map((product) => (
            <ProductCard
              key={product.id}
              product={product}
              onView={onView}
              onAddToCart={onAddToCart}
              isWishlisted={wishlist.includes(product.id)}
              onWishlist={onWishlist}
            />
          ))}
        </div>
      </div>
    </section>
  );
}
