import { CartItem } from "../data";

interface CartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  items: CartItem[];
  onRemove: (id: number) => void;
  onUpdateQty: (id: number, qty: number) => void;
  onCheckout: () => void;
}

export default function CartDrawer({ isOpen, onClose, items, onRemove, onUpdateQty, onCheckout }: CartDrawerProps) {
  const subtotal = items.reduce((sum, item) => sum + item.product.price * item.quantity, 0);
  const shipping = subtotal >= 999 ? 0 : 99;
  const total = subtotal + shipping;

  return (
    <>
      {/* Backdrop */}
      {isOpen && (
        <div
          className="fixed inset-0 bg-charcoal/30 backdrop-blur-sm z-40"
          onClick={onClose}
        />
      )}

      {/* Drawer */}
      <div className={`cart-drawer ${isOpen ? "open" : ""} fixed top-0 right-0 h-full w-full max-w-md bg-ivory z-50 flex flex-col shadow-2xl`}>
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-5 border-b border-linen">
          <h2 className="font-display text-2xl text-charcoal">Your Bag</h2>
          <button onClick={onClose} className="text-stone hover:text-charcoal transition-colors">
            <svg width="22" height="22" fill="none" stroke="currentColor" strokeWidth="1.5" viewBox="0 0 24 24">
              <path strokeLinecap="round" d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>

        {/* Items */}
        <div className="flex-1 overflow-y-auto px-6 py-6">
          {items.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-full gap-4 text-center">
              <svg width="48" height="48" fill="none" stroke="#5B6B86" strokeWidth="1" viewBox="0 0 24 24">
                <path strokeLinecap="round" d="M15.75 10.5V6a3.75 3.75 0 10-7.5 0v4.5m11.356-1.993l1.263 12c.07.665-.45 1.243-1.119 1.243H4.25a1.125 1.125 0 01-1.12-1.243l1.264-12A1.125 1.125 0 015.513 7.5h12.974c.576 0 1.059.435 1.119 1.007z" />
              </svg>
              <p className="font-display text-xl text-stone">Your bag is empty</p>
              <p className="text-sm text-stone font-sans">Add some products to get started</p>
            </div>
          ) : (
            <div className="flex flex-col gap-6">
              {items.map((item) => (
                <div key={item.product.id} className="flex gap-4">
                  <img
                    src={item.product.image}
                    alt={item.product.name}
                    className="w-20 h-24 object-cover bg-warm shrink-0"
                  />
                  <div className="flex-1 flex flex-col gap-1.5">
                    <p className="text-sm font-medium text-charcoal font-sans leading-snug">{item.product.name}</p>
                    <p className="text-xs text-stone font-sans">₹{item.product.price}</p>
                    <div className="flex items-center justify-between mt-auto">
                      <div className="flex items-center border border-linen">
                        <button
                          onClick={() => item.quantity > 1 ? onUpdateQty(item.product.id, item.quantity - 1) : onRemove(item.product.id)}
                          className="w-8 h-8 flex items-center justify-center text-charcoal hover:text-bronze text-sm"
                        >
                          −
                        </button>
                        <span className="w-8 h-8 flex items-center justify-center text-xs font-sans border-x border-linen text-charcoal">
                          {item.quantity}
                        </span>
                        <button
                          onClick={() => onUpdateQty(item.product.id, item.quantity + 1)}
                          className="w-8 h-8 flex items-center justify-center text-charcoal hover:text-bronze text-sm"
                        >
                          +
                        </button>
                      </div>
                      <div className="flex items-center gap-3">
                        <span className="text-sm font-medium text-charcoal font-sans">
                          ₹{item.product.price * item.quantity}
                        </span>
                        <button
                          onClick={() => onRemove(item.product.id)}
                          className="text-stone hover:text-charcoal transition-colors"
                          aria-label="Remove"
                        >
                          <svg width="14" height="14" fill="none" stroke="currentColor" strokeWidth="1.5" viewBox="0 0 24 24">
                            <path strokeLinecap="round" d="M14.74 9l-.346 9m-4.788 0L9.26 9m9.968-3.21c.342.052.682.107 1.022.166m-1.022-.165L18.16 19.673a2.25 2.25 0 01-2.244 2.077H8.084a2.25 2.25 0 01-2.244-2.077L4.772 5.79m14.456 0a48.108 48.108 0 00-3.478-.397m-12 .562c.34-.059.68-.114 1.022-.165m0 0a48.11 48.11 0 013.478-.397m7.5 0v-.916c0-1.18-.91-2.164-2.09-2.201a51.964 51.964 0 00-3.32 0c-1.18.037-2.09 1.022-2.09 2.201v.916m7.5 0a48.667 48.667 0 00-7.5 0" />
                          </svg>
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Footer */}
        {items.length > 0 && (
          <div className="border-t border-linen px-6 py-6 flex flex-col gap-4 bg-warm">
            <div className="flex flex-col gap-2 text-sm font-sans">
              <div className="flex justify-between text-charcoal">
                <span>Subtotal</span>
                <span>₹{subtotal}</span>
              </div>
              <div className="flex justify-between text-stone">
                <span>Shipping</span>
                <span>{shipping === 0 ? <span className="text-bronze">Free</span> : `₹${shipping}`}</span>
              </div>
              {shipping > 0 && (
                <p className="text-xs text-stone">Add ₹{999 - subtotal} more for free shipping</p>
              )}
              <div className="flex justify-between font-semibold text-charcoal text-base pt-2 border-t border-linen">
                <span>Total</span>
                <span>₹{total}</span>
              </div>
            </div>

            <button
              onClick={() => { onClose(); onCheckout(); }}
              className="w-full bg-charcoal text-ivory py-4 text-sm tracking-widest uppercase font-sans hover:bg-bronze transition-colors duration-300"
            >
              Proceed to Checkout
            </button>
          </div>
        )}
      </div>
    </>
  );
}
