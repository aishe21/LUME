import { useState } from "react";
import { products, Product } from "../data";

interface AIAssistantProps {
  onAddToCart: (product: Product) => void;
  onView: (product: Product) => void;
}

const concerns = [
  { id: "hydration", label: "Hydration", icon: "💧" },
  { id: "glow", label: "Glow", icon: "✨" },
  { id: "oilcontrol", label: "Oil Control", icon: "⚖️" },
  { id: "sensitive", label: "Sensitive Skin", icon: "🌿" },
  { id: "body", label: "Body Care", icon: "🛁" },
  { id: "hair", label: "Hair Care", icon: "🌾" },
];

const recommendations: Record<string, number[]> = {
  hydration: [4, 1, 3],
  glow: [2, 1, 7],
  oilcontrol: [5, 7, 16],
  sensitive: [8, 6, 15],
  body: [9, 11, 10],
  hair: [21, 22, 23],
};

export default function AIAssistant({ onAddToCart, onView }: AIAssistantProps) {
  const [step, setStep] = useState<"start" | "concern" | "results">("start");
  const [selectedConcern, setSelectedConcern] = useState<string | null>(null);
  const [added, setAdded] = useState<number[]>([]);

  const recProducts = selectedConcern
    ? (recommendations[selectedConcern] || []).map((id) => products.find((p) => p.id === id)).filter(Boolean) as Product[]
    : [];

  const handleAdd = (product: Product) => {
    onAddToCart(product);
    setAdded((prev) => [...prev, product.id]);
  };

  return (
    <section className="py-24 px-6 lg:px-8 bg-charcoal text-ivory">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-12">
          <p className="text-xs tracking-[0.25em] uppercase text-sage font-sans mb-3">AI-Powered</p>
          <h2 className="font-display text-4xl lg:text-5xl text-ivory mb-4">Find Your Ritual</h2>
          <p className="text-stone font-sans text-base">
            Let us help you build a personalised skincare routine.
          </p>
        </div>

        <div className="bg-charcoal border border-stone/20 p-8 lg:p-12">
          {step === "start" && (
            <div className="text-center flex flex-col items-center gap-6">
              <div className="w-16 h-16 border border-sage/50 flex items-center justify-center">
                <svg width="24" height="24" fill="none" stroke="#8CA0C4" strokeWidth="1.5" viewBox="0 0 24 24">
                  <path strokeLinecap="round" d="M9.813 15.904L9 18.75l-.813-2.846a4.5 4.5 0 00-3.09-3.09L2.25 12l2.846-.813a4.5 4.5 0 003.09-3.09L9 5.25l.813 2.846a4.5 4.5 0 003.09 3.09L15.75 12l-2.846.813a4.5 4.5 0 00-3.09 3.09z" />
                </svg>
              </div>
              <p className="font-display text-2xl text-ivory">What are you looking for?</p>
              <p className="text-sm text-stone font-sans">Tell us your skin concern and we'll suggest the right products for you.</p>
              <button
                onClick={() => setStep("concern")}
                className="bg-sage text-charcoal px-10 py-4 text-sm tracking-widest uppercase font-sans hover:bg-sage-deep hover:text-ivory transition-colors"
              >
                Get Started
              </button>
            </div>
          )}

          {step === "concern" && (
            <div className="flex flex-col gap-8">
              <p className="font-display text-2xl text-ivory text-center">What is your main concern?</p>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                {concerns.map((c) => (
                  <button
                    key={c.id}
                    onClick={() => { setSelectedConcern(c.id); setStep("results"); }}
                    className={`flex flex-col items-center gap-3 p-5 border transition-all duration-200 hover:border-sage ${selectedConcern === c.id ? "border-sage bg-sage/10" : "border-stone/20"}`}
                  >
                    <span className="text-2xl">{c.icon}</span>
                    <span className="text-sm font-sans text-ivory">{c.label}</span>
                  </button>
                ))}
              </div>
            </div>
          )}

          {step === "results" && recProducts.length > 0 && (
            <div className="flex flex-col gap-8">
              <div className="text-center">
                <p className="text-stone text-xs uppercase tracking-widest font-sans mb-2">Your recommendation</p>
                <p className="font-display text-2xl text-ivory">
                  Based on your preferences, these products may fit your routine.
                </p>
              </div>
              <div className="grid sm:grid-cols-3 gap-6">
                {recProducts.map((p) => (
                  <div key={p.id} className="border border-stone/20 p-4 flex flex-col gap-3">
                    <img
                      src={p.image}
                      alt={p.name}
                      className="w-full aspect-square object-cover bg-warm/10"
                    />
                    <div>
                      <p className="text-sm font-medium text-ivory font-sans">{p.name}</p>
                      <p className="text-xs text-stone font-sans mt-1">₹{p.price}</p>
                    </div>
                    <div className="flex gap-2 mt-auto">
                      <button
                        onClick={() => onView(p)}
                        className="flex-1 border border-stone/30 text-ivory text-xs py-2.5 font-sans hover:border-sage transition-colors"
                      >
                        View
                      </button>
                      <button
                        onClick={() => handleAdd(p)}
                        className="flex-1 bg-sage text-charcoal text-xs py-2.5 font-sans hover:bg-sage-deep hover:text-ivory transition-colors"
                      >
                        {added.includes(p.id) ? "Added ✓" : "Add to Bag"}
                      </button>
                    </div>
                  </div>
                ))}
              </div>
              <button
                onClick={() => { setStep("concern"); setSelectedConcern(null); setAdded([]); }}
                className="self-center text-sm text-stone hover:text-ivory font-sans underline underline-offset-4 transition-colors"
              >
                ← Try a different concern
              </button>
            </div>
          )}
        </div>
      </div>
    </section>
  );
}
