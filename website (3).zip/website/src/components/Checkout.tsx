import { useState } from "react";
import { CartItem } from "../data";

interface CheckoutProps {
  items: CartItem[];
  onBack: () => void;
  onSuccess: () => void;
}

type Step = "contact" | "shipping" | "payment" | "success";

export default function Checkout({ items, onBack, onSuccess }: CheckoutProps) {
  const [step, setStep] = useState<Step>("contact");
  const [form, setForm] = useState({
    email: "",
    firstName: "",
    lastName: "",
    phone: "",
    address: "",
    city: "",
    state: "",
    pincode: "",
    delivery: "standard",
    cardNumber: "",
    expiry: "",
    cvv: "",
    nameOnCard: "",
    coupon: "",
    couponApplied: false,
  });

  const subtotal = items.reduce((sum, i) => sum + i.product.price * i.quantity, 0);
  const shipping = form.delivery === "express" ? 149 : subtotal >= 999 ? 0 : 99;
  const discount = form.couponApplied ? Math.round(subtotal * 0.1) : 0;
  const total = subtotal + shipping - discount;

  const update = (key: string, val: string | boolean) => setForm((f) => ({ ...f, [key]: val }));

  const handleCoupon = () => {
    if (form.coupon.toUpperCase() === "RITUAL10") {
      update("couponApplied", true);
    }
  };

  if (step === "success") {
    return (
      <div className="min-h-screen bg-ivory flex items-center justify-center px-6">
        <div className="text-center max-w-md">
          <div className="w-16 h-16 border border-bronze flex items-center justify-center mx-auto mb-8">
            <svg width="24" height="24" fill="none" stroke="#8CA0C4" strokeWidth="1.5" viewBox="0 0 24 24">
              <path strokeLinecap="round" d="M4.5 12.75l6 6 9-13.5" />
            </svg>
          </div>
          <h2 className="font-display text-4xl text-charcoal mb-4">Order Placed!</h2>
          <p className="text-stone font-sans mb-2">Thank you for your order. You will receive a confirmation email shortly.</p>
          <p className="text-xs text-stone font-sans mb-10">Order #LM{Math.floor(Math.random() * 90000 + 10000)}</p>
          <button
            onClick={() => { onSuccess(); onBack(); }}
            className="bg-charcoal text-ivory px-10 py-4 text-sm tracking-widest uppercase font-sans hover:bg-bronze transition-colors"
          >
            Continue Shopping
          </button>
        </div>
      </div>
    );
  }

  const steps: Step[] = ["contact", "shipping", "payment"];
  const stepLabels = ["Contact", "Shipping", "Payment"];

  return (
    <div className="min-h-screen bg-ivory">
      {/* Header */}
      <div className="border-b border-linen py-5 px-6 lg:px-8 flex items-center justify-between">
        <button onClick={onBack} className="text-sm text-stone hover:text-charcoal font-sans flex items-center gap-2">
          <svg width="16" height="16" fill="none" stroke="currentColor" strokeWidth="1.5" viewBox="0 0 24 24"><path strokeLinecap="round" d="M10.5 19.5L3 12m0 0l7.5-7.5M3 12h18" /></svg>
          Back to shop
        </button>
        <span className="font-display text-2xl text-charcoal tracking-wider">LUM<span className="text-bronze">É</span></span>
        <div className="w-20" />
      </div>

      <div className="max-w-6xl mx-auto px-6 lg:px-8 py-10 grid lg:grid-cols-[1fr_400px] gap-16">
        {/* Left: Form */}
        <div>
          {/* Step Indicators */}
          <div className="flex items-center gap-2 mb-10">
            {steps.map((s, i) => (
              <div key={s} className="flex items-center gap-2">
                <div className={`w-7 h-7 flex items-center justify-center text-xs font-sans border transition-colors ${step === s || steps.indexOf(step) > i ? "bg-charcoal border-charcoal text-ivory" : "border-linen text-stone"}`}>
                  {steps.indexOf(step) > i ? "✓" : i + 1}
                </div>
                <span className={`text-xs uppercase tracking-widest font-sans hidden sm:block ${step === s ? "text-charcoal" : "text-stone"}`}>
                  {stepLabels[i]}
                </span>
                {i < steps.length - 1 && <div className="w-8 h-px bg-linen mx-1" />}
              </div>
            ))}
          </div>

          {step === "contact" && (
            <div className="flex flex-col gap-5">
              <h2 className="font-display text-2xl text-charcoal">Contact Information</h2>
              <input
                type="email"
                placeholder="Email address"
                value={form.email}
                onChange={(e) => update("email", e.target.value)}
                className="w-full border border-linen px-4 py-3.5 text-sm font-sans text-charcoal bg-ivory placeholder-stone"
              />
              <div className="grid grid-cols-2 gap-4">
                <input
                  type="text"
                  placeholder="First name"
                  value={form.firstName}
                  onChange={(e) => update("firstName", e.target.value)}
                  className="border border-linen px-4 py-3.5 text-sm font-sans text-charcoal bg-ivory placeholder-stone"
                />
                <input
                  type="text"
                  placeholder="Last name"
                  value={form.lastName}
                  onChange={(e) => update("lastName", e.target.value)}
                  className="border border-linen px-4 py-3.5 text-sm font-sans text-charcoal bg-ivory placeholder-stone"
                />
              </div>
              <input
                type="tel"
                placeholder="Phone number"
                value={form.phone}
                onChange={(e) => update("phone", e.target.value)}
                className="w-full border border-linen px-4 py-3.5 text-sm font-sans text-charcoal bg-ivory placeholder-stone"
              />
              <button
                onClick={() => setStep("shipping")}
                disabled={!form.email || !form.firstName}
                className="bg-charcoal text-ivory py-4 text-sm tracking-widest uppercase font-sans hover:bg-bronze transition-colors disabled:opacity-40 disabled:cursor-not-allowed"
              >
                Continue to Shipping
              </button>
            </div>
          )}

          {step === "shipping" && (
            <div className="flex flex-col gap-5">
              <h2 className="font-display text-2xl text-charcoal">Shipping Address</h2>
              <input
                type="text"
                placeholder="Address"
                value={form.address}
                onChange={(e) => update("address", e.target.value)}
                className="w-full border border-linen px-4 py-3.5 text-sm font-sans text-charcoal bg-ivory placeholder-stone"
              />
              <div className="grid grid-cols-2 gap-4">
                <input
                  type="text"
                  placeholder="City"
                  value={form.city}
                  onChange={(e) => update("city", e.target.value)}
                  className="border border-linen px-4 py-3.5 text-sm font-sans text-charcoal bg-ivory placeholder-stone"
                />
                <input
                  type="text"
                  placeholder="State"
                  value={form.state}
                  onChange={(e) => update("state", e.target.value)}
                  className="border border-linen px-4 py-3.5 text-sm font-sans text-charcoal bg-ivory placeholder-stone"
                />
              </div>
              <input
                type="text"
                placeholder="Pincode"
                value={form.pincode}
                onChange={(e) => update("pincode", e.target.value)}
                className="w-full border border-linen px-4 py-3.5 text-sm font-sans text-charcoal bg-ivory placeholder-stone"
              />
              <div className="border border-linen p-5">
                <p className="text-xs uppercase tracking-widest text-stone font-sans mb-4">Delivery Method</p>
                <div className="flex flex-col gap-3">
                  {[
                    { id: "standard", label: "Standard Delivery", sub: "5–7 business days", price: subtotal >= 999 ? "Free" : "₹99" },
                    { id: "express", label: "Express Delivery", sub: "2–3 business days", price: "₹149" },
                  ].map((opt) => (
                    <label key={opt.id} className={`flex items-center justify-between p-4 border cursor-pointer transition-colors ${form.delivery === opt.id ? "border-charcoal" : "border-linen"}`}>
                      <div className="flex items-center gap-3">
                        <input
                          type="radio"
                          name="delivery"
                          checked={form.delivery === opt.id}
                          onChange={() => update("delivery", opt.id)}
                          className="accent-bronze"
                        />
                        <div>
                          <p className="text-sm font-sans text-charcoal font-medium">{opt.label}</p>
                          <p className="text-xs text-stone font-sans">{opt.sub}</p>
                        </div>
                      </div>
                      <span className="text-sm font-sans text-charcoal">{opt.price}</span>
                    </label>
                  ))}
                </div>
              </div>
              <div className="flex gap-3">
                <button onClick={() => setStep("contact")} className="border border-linen text-charcoal px-6 py-4 text-sm font-sans hover:border-charcoal transition-colors">
                  Back
                </button>
                <button
                  onClick={() => setStep("payment")}
                  disabled={!form.address || !form.city}
                  className="flex-1 bg-charcoal text-ivory py-4 text-sm tracking-widest uppercase font-sans hover:bg-bronze transition-colors disabled:opacity-40"
                >
                  Continue to Payment
                </button>
              </div>
            </div>
          )}

          {step === "payment" && (
            <div className="flex flex-col gap-5">
              <h2 className="font-display text-2xl text-charcoal">Payment</h2>
              <div className="border border-linen p-5 flex flex-col gap-4">
                <p className="text-xs uppercase tracking-widest text-stone font-sans">Card Details</p>
                <input
                  type="text"
                  placeholder="Card number"
                  maxLength={19}
                  value={form.cardNumber}
                  onChange={(e) => update("cardNumber", e.target.value)}
                  className="w-full border border-linen px-4 py-3.5 text-sm font-sans text-charcoal bg-ivory placeholder-stone"
                />
                <div className="grid grid-cols-2 gap-4">
                  <input
                    type="text"
                    placeholder="MM / YY"
                    maxLength={5}
                    value={form.expiry}
                    onChange={(e) => update("expiry", e.target.value)}
                    className="border border-linen px-4 py-3.5 text-sm font-sans text-charcoal bg-ivory placeholder-stone"
                  />
                  <input
                    type="text"
                    placeholder="CVV"
                    maxLength={3}
                    value={form.cvv}
                    onChange={(e) => update("cvv", e.target.value)}
                    className="border border-linen px-4 py-3.5 text-sm font-sans text-charcoal bg-ivory placeholder-stone"
                  />
                </div>
                <input
                  type="text"
                  placeholder="Name on card"
                  value={form.nameOnCard}
                  onChange={(e) => update("nameOnCard", e.target.value)}
                  className="w-full border border-linen px-4 py-3.5 text-sm font-sans text-charcoal bg-ivory placeholder-stone"
                />
              </div>
              {/* Coupon */}
              <div className="flex gap-3">
                <input
                  type="text"
                  placeholder="Coupon code"
                  value={form.coupon}
                  onChange={(e) => update("coupon", e.target.value)}
                  className="flex-1 border border-linen px-4 py-3 text-sm font-sans text-charcoal bg-ivory placeholder-stone"
                />
                <button onClick={handleCoupon} className="border border-charcoal text-charcoal px-5 py-3 text-xs uppercase tracking-widest font-sans hover:bg-charcoal hover:text-ivory transition-colors">
                  Apply
                </button>
              </div>
              {form.couponApplied && (
                <p className="text-xs text-bronze font-sans">Coupon RITUAL10 applied — 10% off!</p>
              )}
              <div className="flex gap-3">
                <button onClick={() => setStep("shipping")} className="border border-linen text-charcoal px-6 py-4 text-sm font-sans hover:border-charcoal transition-colors">
                  Back
                </button>
                <button
                  onClick={() => setStep("success")}
                  disabled={!form.cardNumber || !form.expiry}
                  className="flex-1 bg-charcoal text-ivory py-4 text-sm tracking-widest uppercase font-sans hover:bg-bronze transition-colors disabled:opacity-40"
                >
                  Place Order · ₹{total}
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Right: Order Summary */}
        <div className="bg-warm p-6 h-fit sticky top-24">
          <h3 className="font-display text-xl text-charcoal mb-6">Order Summary</h3>
          <div className="flex flex-col gap-4 mb-6">
            {items.map((item) => (
              <div key={item.product.id} className="flex gap-3">
                <div className="relative shrink-0">
                  <img src={item.product.image} alt={item.product.name} className="w-16 h-16 object-cover bg-ivory" />
                  <span className="absolute -top-1.5 -right-1.5 bg-charcoal text-ivory text-[10px] w-5 h-5 rounded-full flex items-center justify-center font-sans">
                    {item.quantity}
                  </span>
                </div>
                <div className="flex-1">
                  <p className="text-xs font-sans text-charcoal font-medium leading-snug">{item.product.name}</p>
                  <p className="text-xs text-stone font-sans mt-1">₹{item.product.price * item.quantity}</p>
                </div>
              </div>
            ))}
          </div>
          <div className="border-t border-linen pt-4 flex flex-col gap-2 text-sm font-sans">
            <div className="flex justify-between text-charcoal">
              <span>Subtotal</span>
              <span>₹{subtotal}</span>
            </div>
            <div className="flex justify-between text-stone">
              <span>Shipping</span>
              <span>{shipping === 0 ? "Free" : `₹${shipping}`}</span>
            </div>
            {discount > 0 && (
              <div className="flex justify-between text-bronze">
                <span>Discount</span>
                <span>−₹{discount}</span>
              </div>
            )}
            <div className="flex justify-between font-semibold text-charcoal text-base pt-2 border-t border-linen mt-1">
              <span>Total</span>
              <span>₹{total}</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
