import { useState } from "react";
import { products, Product } from "../data";

interface RoutineBuilderProps {
  onAddToCart: (product: Product) => void;
}

const routines = {
  morning: [
    { step: "Cleanser", productId: 6 },
    { step: "Serum", productId: 1 },
    { step: "Moisturizer", productId: 3 },
  ],
  evening: [
    { step: "Cleanser", productId: 6 },
    { step: "Serum", productId: 4 },
    { step: "Moisturizer", productId: 3 },
  ],
  body: [
    { step: "Body Wash", productId: 11 },
    { step: "Body Scrub", productId: 12 },
    { step: "Body Lotion", productId: 10 },
  ],
};

type RoutineKey = keyof typeof routines;

export default function RoutineBuilder({ onAddToCart }: RoutineBuilderProps) {
  const [active, setActive] = useState<RoutineKey>("morning");
  const [added, setAdded] = useState(false);

  const steps = routines[active].map((s) => ({
    step: s.step,
    product: products.find((p) => p.id === s.productId)!,
  }));

  const total = steps.reduce((sum, s) => sum + s.product.price, 0);

  const handleAddAll = () => {
    steps.forEach((s) => onAddToCart(s.product));
    setAdded(true);
    setTimeout(() => setAdded(false), 2000);
  };

  return (
    <section className="py-24 px-6 lg:px-8 bg-warm">
      <div className="max-w-5xl mx-auto">
        <div className="text-center mb-12">
          <p className="text-xs tracking-[0.25em] uppercase text-olive font-sans mb-3">Curated for you</p>
          <h2 className="font-display text-4xl lg:text-5xl text-charcoal mb-4">Build Your Routine</h2>
          <p className="text-stone font-sans text-sm">Add an entire routine to your bag in one click.</p>
        </div>

        {/* Tab Switcher */}
        <div className="flex border border-linen mb-10 max-w-sm mx-auto">
          {(Object.keys(routines) as RoutineKey[]).map((key) => (
            <button
              key={key}
              onClick={() => { setActive(key); setAdded(false); }}
              className={`flex-1 py-3 text-xs tracking-widest uppercase font-sans transition-all ${active === key ? "bg-olive text-ivory" : "text-stone hover:text-olive hover:bg-petal"}`}
            >
              {key.charAt(0).toUpperCase() + key.slice(1)}
            </button>
          ))}
        </div>

        {/* Steps */}
        <div className="relative">
          <div className="grid sm:grid-cols-3 gap-6">
            {steps.map((s, i) => (
              <div key={i} className="relative">
                {/* Connector line */}
                {i < steps.length - 1 && (
                  <div className="hidden sm:block absolute top-16 left-[calc(100%+12px)] right-0 w-6 h-px bg-linen z-10" />
                )}
                <div className="bg-ivory border border-linen p-5 flex flex-col gap-4">
                  <div className="flex items-center gap-3">
                    <span className="font-display text-4xl text-linen leading-none">0{i + 1}</span>
                    <div>
                      <p className="text-[10px] text-stone uppercase tracking-widest font-sans">Step {i + 1}</p>
                      <p className="text-sm font-medium text-charcoal font-sans">{s.step}</p>
                    </div>
                  </div>
                  <img
                    src={s.product.image}
                    alt={s.product.name}
                    className="w-full aspect-[4/3] object-cover bg-warm"
                  />
                  <div>
                    <p className="text-sm font-medium text-charcoal font-sans">{s.product.name}</p>
                    <p className="text-xs text-stone font-sans mt-1">₹{s.product.price}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Add All CTA */}
        <div className="mt-10 flex flex-col sm:flex-row items-center justify-between gap-4 bg-ivory border border-linen px-6 py-5">
          <div>
            <p className="text-xs text-stone font-sans uppercase tracking-widest mb-1">Routine total</p>
            <p className="font-display text-2xl text-charcoal">₹{total}</p>
          </div>
          <button
            onClick={handleAddAll}
            className="bg-olive text-ivory px-10 py-4 text-sm tracking-widest uppercase font-sans hover:bg-charcoal transition-colors duration-300 min-w-[200px]"
          >
            {added ? "Added to Bag ✓" : "Add Routine to Bag"}
          </button>
        </div>
      </div>
    </section>
  );
}
