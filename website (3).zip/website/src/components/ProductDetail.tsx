import { useState } from "react";
import { Product } from "../data";

interface ProductDetailProps {
  product: Product;
  onAddToCart: (product: Product, qty: number) => void;
  isWishlisted: boolean;
  onWishlist: (id: number) => void;
  onNavigate: (page: string, product?: Product, category?: string) => void;
}

function Stars({ rating, reviewCount }: { rating: number; reviewCount: number }) {
  return (
    <div className="flex items-center gap-2">
      <div className="flex items-center gap-0.5">
        {[1, 2, 3, 4, 5].map((s) => (
          <svg key={s} width="14" height="14" viewBox="0 0 20 20" fill={s <= Math.round(rating) ? "#8CA0C4" : "none"} stroke="#8CA0C4" strokeWidth="1.5">
            <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.286 3.956a1 1 0 00.95.69h4.162c.969 0 1.371 1.24.588 1.81l-3.37 2.448a1 1 0 00-.364 1.118l1.287 3.957c.3.921-.755 1.688-1.54 1.118L10 15.347l-3.95 2.877c-.784.57-1.838-.197-1.539-1.118l1.287-3.957a1 1 0 00-.364-1.118L2.064 9.383c-.784-.57-.38-1.81.588-1.81h4.162a1 1 0 00.95-.69l1.285-3.956z" />
          </svg>
        ))}
      </div>
      <span className="text-sm text-stone font-sans">{rating} ({reviewCount} reviews)</span>
    </div>
  );
}

const reviewData = [
  { name: "Priya S.", rating: 5, review: "Feels lightweight and leaves my skin feeling fresh. I use it every morning now.", date: "2 weeks ago" },
  { name: "Aarav M.", rating: 5, review: "Beautiful packaging and texture. The results are noticeable within a week.", date: "1 month ago" },
  { name: "Sneha R.", rating: 4, review: "Really nice product. My skin feels hydrated and soft throughout the day.", date: "1 month ago" },
];

export default function ProductDetail({ product, onAddToCart, isWishlisted, onWishlist, onNavigate }: ProductDetailProps) {
  const [qty, setQty] = useState(1);
  const [activeImage, setActiveImage] = useState(0);
  const [activeTab, setActiveTab] = useState<"benefits" | "ingredients" | "how-to">("benefits");
  const [added, setAdded] = useState(false);

  const handleAdd = () => {
    onAddToCart(product, qty);
    setAdded(true);
    setTimeout(() => setAdded(false), 1800);
  };

  const discount = product.originalPrice
    ? Math.round(((product.originalPrice - product.price) / product.originalPrice) * 100)
    : null;

  return (
    <div className="min-h-screen bg-ivory">
      {/* Breadcrumb */}
      <div className="max-w-7xl mx-auto px-6 lg:px-8 py-5 flex items-center gap-2 text-xs text-stone font-sans">
        <button onClick={() => onNavigate("home")} className="hover:text-bronze transition-colors">Home</button>
        <span>/</span>
        <button onClick={() => onNavigate("shop", undefined, product.category)} className="hover:text-bronze transition-colors capitalize">{product.category}</button>
        <span>/</span>
        <span className="text-charcoal">{product.name}</span>
      </div>

      <div className="max-w-7xl mx-auto px-6 lg:px-8 pb-24">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-20">
          {/* Gallery */}
          <div className="flex flex-col gap-4">
            <div className="aspect-square bg-warm overflow-hidden">
              <img
                src={product.images[activeImage]}
                alt={product.name}
                className="w-full h-full object-cover transition-all duration-500"
              />
            </div>
            {product.images.length > 1 && (
              <div className="flex gap-3">
                {product.images.map((img, i) => (
                  <button
                    key={i}
                    onClick={() => setActiveImage(i)}
                    className={`w-20 h-20 overflow-hidden border-2 transition-colors ${activeImage === i ? "border-bronze" : "border-transparent"}`}
                  >
                    <img src={img} alt="" className="w-full h-full object-cover" />
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Info */}
          <div className="flex flex-col gap-6">
            {/* Header */}
            <div className="flex flex-col gap-3">
              <div className="flex items-center gap-2">
                {product.isNew && <span className="text-[10px] tracking-widest uppercase bg-charcoal text-ivory px-2.5 py-1 font-sans">New</span>}
                {product.badge && <span className="text-[10px] tracking-widest uppercase bg-bronze text-ivory px-2.5 py-1 font-sans">{product.badge}</span>}
              </div>
              <h1 className="font-display text-3xl lg:text-4xl text-charcoal">{product.name}</h1>
              <Stars rating={product.rating} reviewCount={product.reviewCount} />
            </div>

            {/* Price */}
            <div className="flex items-center gap-3 py-4 border-y border-linen">
              <span className="font-sans text-2xl font-semibold text-charcoal">₹{product.price}</span>
              {product.originalPrice && (
                <>
                  <span className="font-sans text-lg text-stone line-through">₹{product.originalPrice}</span>
                  <span className="text-sm text-bronze font-sans">{discount}% off</span>
                </>
              )}
            </div>

            {/* Description */}
            <p className="text-sm text-stone font-sans leading-relaxed">{product.description}</p>

            {/* Quantity */}
            <div className="flex items-center gap-4">
              <span className="text-xs tracking-widest uppercase text-charcoal font-sans">Qty</span>
              <div className="flex items-center border border-linen">
                <button
                  onClick={() => setQty(Math.max(1, qty - 1))}
                  className="w-10 h-10 flex items-center justify-center text-charcoal hover:text-bronze transition-colors"
                >
                  −
                </button>
                <span className="w-10 h-10 flex items-center justify-center text-sm font-sans text-charcoal border-x border-linen">
                  {qty}
                </span>
                <button
                  onClick={() => setQty(qty + 1)}
                  className="w-10 h-10 flex items-center justify-center text-charcoal hover:text-bronze transition-colors"
                >
                  +
                </button>
              </div>
            </div>

            {/* CTA Buttons */}
            <div className="flex flex-col sm:flex-row gap-3">
              <button
                onClick={handleAdd}
                className="flex-1 bg-charcoal text-ivory py-4 text-sm tracking-widest uppercase font-sans hover:bg-bronze transition-colors duration-300"
              >
                {added ? "Added to Bag ✓" : "Add to Bag"}
              </button>
              <button
                onClick={() => { onAddToCart(product, qty); onNavigate("checkout"); }}
                className="flex-1 border border-charcoal text-charcoal py-4 text-sm tracking-widest uppercase font-sans hover:bg-charcoal hover:text-ivory transition-colors duration-300"
              >
                Buy Now
              </button>
              <button
                onClick={() => onWishlist(product.id)}
                className="w-14 h-14 border border-linen flex items-center justify-center hover:border-bronze transition-colors shrink-0"
                aria-label="Wishlist"
              >
                <svg width="18" height="18" fill={isWishlisted ? "#8CA0C4" : "none"} stroke="#8CA0C4" strokeWidth="1.5" viewBox="0 0 24 24">
                  <path strokeLinecap="round" d="M21 8.25c0-2.485-2.099-4.5-4.688-4.5-1.935 0-3.597 1.126-4.312 2.733-.715-1.607-2.377-2.733-4.313-2.733C5.1 3.75 3 5.765 3 8.25c0 7.22 9 12 9 12s9-4.78 9-12z" />
                </svg>
              </button>
            </div>

            {/* Tabs */}
            <div className="border-t border-linen pt-6">
              <div className="flex gap-6 border-b border-linen mb-6">
                {(["benefits", "ingredients", "how-to"] as const).map((tab) => (
                  <button
                    key={tab}
                    onClick={() => setActiveTab(tab)}
                    className={`pb-3 text-xs tracking-widest uppercase font-sans transition-colors ${activeTab === tab ? "text-bronze border-b-2 border-bronze" : "text-stone hover:text-charcoal"}`}
                  >
                    {tab === "how-to" ? "How to Use" : tab}
                  </button>
                ))}
              </div>

              {activeTab === "benefits" && (
                <ul className="flex flex-col gap-3">
                  {product.benefits.map((b) => (
                    <li key={b} className="flex items-center gap-3 text-sm text-charcoal font-sans">
                      <span className="w-4 h-4 rounded-full border border-bronze flex items-center justify-center shrink-0">
                        <svg width="8" height="8" viewBox="0 0 12 12" fill="#8CA0C4"><path d="M2 6l3 3 5-5" stroke="#8CA0C4" strokeWidth="1.5" fill="none" strokeLinecap="round" /></svg>
                      </span>
                      {b}
                    </li>
                  ))}
                </ul>
              )}

              {activeTab === "ingredients" && (
                <div className="grid grid-cols-2 gap-3">
                  {product.ingredients.map((ing) => (
                    <div key={ing} className="bg-warm px-4 py-3">
                      <p className="text-xs font-sans font-medium text-charcoal">{ing}</p>
                    </div>
                  ))}
                </div>
              )}

              {activeTab === "how-to" && (
                <ol className="flex flex-col gap-4">
                  {product.howToUse.map((step, i) => (
                    <li key={i} className="flex items-start gap-4 text-sm font-sans text-charcoal">
                      <span className="font-display text-bronze text-lg leading-none mt-0.5 shrink-0">0{i + 1}</span>
                      <span>{step}</span>
                    </li>
                  ))}
                </ol>
              )}
            </div>
          </div>
        </div>

        {/* Reviews */}
        <div className="mt-24 pt-16 border-t border-linen">
          <h2 className="font-display text-3xl text-charcoal mb-10">Customer Reviews</h2>
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {reviewData.map((r, i) => (
              <div key={i} className="bg-warm p-6">
                <div className="flex items-center gap-1 mb-3">
                  {[1, 2, 3, 4, 5].map((s) => (
                    <svg key={s} width="11" height="11" viewBox="0 0 20 20" fill={s <= r.rating ? "#8CA0C4" : "none"} stroke="#8CA0C4" strokeWidth="1.5">
                      <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.286 3.956a1 1 0 00.95.69h4.162c.969 0 1.371 1.24.588 1.81l-3.37 2.448a1 1 0 00-.364 1.118l1.287 3.957c.3.921-.755 1.688-1.54 1.118L10 15.347l-3.95 2.877c-.784.57-1.838-.197-1.539-1.118l1.287-3.957a1 1 0 00-.364-1.118L2.064 9.383c-.784-.57-.38-1.81.588-1.81h4.162a1 1 0 00.95-.69l1.285-3.956z" />
                    </svg>
                  ))}
                </div>
                <p className="text-sm text-charcoal font-sans leading-relaxed mb-4">{r.review}</p>
                <div className="flex items-center justify-between">
                  <p className="text-xs font-medium text-charcoal font-sans">{r.name}</p>
                  <p className="text-xs text-stone font-sans">{r.date}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
