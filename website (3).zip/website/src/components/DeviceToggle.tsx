interface DeviceToggleProps {
  device: "desktop" | "mobile";
  onChange: (device: "desktop" | "mobile") => void;
}

export default function DeviceToggle({ device, onChange }: DeviceToggleProps) {
  return (
    <div className="fixed bottom-5 right-5 z-[60] flex items-center gap-1 rounded-full bg-charcoal/95 backdrop-blur px-1.5 py-1.5 shadow-lg border border-bronze/40">
      <button
        type="button"
        onClick={() => onChange("desktop")}
        aria-label="Desktop view"
        aria-pressed={device === "desktop"}
        title="Desktop view"
        className={`flex items-center gap-2 rounded-full px-3 py-1.5 text-xs font-sans tracking-wide transition-colors ${
          device === "desktop" ? "bg-bronze text-ivory" : "text-stone hover:text-ivory"
        }`}
      >
        <svg width="16" height="16" fill="none" stroke="currentColor" strokeWidth="1.5" viewBox="0 0 24 24">
          <rect x="2.5" y="4" width="19" height="12" rx="1.5" />
          <path strokeLinecap="round" d="M9 20h6M12 16v4" />
        </svg>
        <span className="hidden sm:inline">Desktop</span>
      </button>

      <button
        type="button"
        onClick={() => onChange("mobile")}
        aria-label="Mobile view"
        aria-pressed={device === "mobile"}
        title="Mobile view"
        className={`flex items-center gap-2 rounded-full px-3 py-1.5 text-xs font-sans tracking-wide transition-colors ${
          device === "mobile" ? "bg-bronze text-ivory" : "text-stone hover:text-ivory"
        }`}
      >
        <svg width="16" height="16" fill="none" stroke="currentColor" strokeWidth="1.5" viewBox="0 0 24 24">
          <rect x="7" y="2.5" width="10" height="19" rx="2" />
          <path strokeLinecap="round" d="M11 18.5h2" />
        </svg>
        <span className="hidden sm:inline">Mobile</span>
      </button>
    </div>
  );
}
