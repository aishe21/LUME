import { useState } from "react";
import { ingredients, testimonials, galleryImages } from "../data";

function Philosophy() {
  return (
    <section id="about" className="pt-14 pb-24 px-6 lg:px-8 bg-petal scroll-mt-16 lg:scroll-mt-20">
      <div className="max-w-7xl mx-auto grid lg:grid-cols-2 gap-16 items-center">
        <div className="order-2 lg:order-1">
          <p className="text-xs tracking-[0.25em] uppercase text-stone font-sans mb-6">Our Philosophy</p>
          <h2 className="font-display text-4xl lg:text-5xl text-charcoal leading-[1.1] mb-8">
            Beauty,<br /><em>Made Simple.</em>
          </h2>
          <p className="text-base text-stone font-sans leading-relaxed mb-6 max-w-lg">
            We believe everyday skincare should feel simple, thoughtful and enjoyable. Our products are designed around everyday rituals, carefully selected ingredients and a modern approach to personal care.
          </p>
          <p className="text-sm text-stone font-sans leading-relaxed max-w-lg">
            Every formula begins with a clear purpose — and only what is needed to achieve it. No unnecessary fillers, no compromises.
          </p>
          <div className="mt-10 grid grid-cols-3 gap-8">
            {[["Clean", "Carefully selected ingredients"], ["Honest", "Transparent labelling"], ["Purposeful", "Formulated with intent"]].map(([title, desc]) => (
              <div key={title}>
                <div className="w-8 h-px bg-olive mb-3" />
                <p className="font-display text-lg text-charcoal mb-1">{title}</p>
                <p className="text-xs text-stone font-sans leading-relaxed">{desc}</p>
              </div>
            ))}
          </div>
        </div>
        <div className="order-1 lg:order-2 relative h-[460px] bg-warm overflow-hidden">
          <img
            src="https://images.unsplash.com/photo-1739979872134-84280666bc32?w=900&h=900&fit=crop&auto=format"
            alt="Luxury skincare bottles on a shelf"
            className="w-full h-full object-cover"
          />
          <div className="absolute top-8 left-8">
            <div className="w-10 h-10 border-l border-t border-ivory/40" />
          </div>
          <div className="absolute bottom-8 right-8">
            <div className="w-10 h-10 border-r border-b border-ivory/40" />
          </div>
        </div>
      </div>
    </section>
  );
}

function Ingredients() {
  const [active, setActive] = useState<string | null>(null);

  return (
    <section className="py-24 px-6 lg:px-8 bg-ivory">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-14">
          <p className="text-xs tracking-[0.25em] uppercase text-stone font-sans mb-3">What Goes In</p>
          <h2 className="font-display text-4xl lg:text-5xl text-charcoal mb-4">Ingredient Library</h2>
          <p className="text-stone font-sans text-sm max-w-md mx-auto">
            Click an ingredient to learn about its role in our formulas.
          </p>
        </div>

        <div className="grid grid-cols-3 sm:grid-cols-4 lg:grid-cols-6 gap-3">
          {ingredients.map((ing) => (
            <div key={ing.name} className="flex flex-col">
              <button
                onClick={() => setActive(active === ing.name ? null : ing.name)}
                className={`p-4 border flex flex-col items-center gap-2 text-center transition-all duration-200 ${active === ing.name ? "border-bronze bg-petal" : "border-linen hover:border-bronze/50 bg-warm"}`}
              >
                <span className="text-xl font-display text-bronze">{ing.icon}</span>
                <span className="text-xs font-sans font-medium text-charcoal leading-snug">{ing.name}</span>
              </button>
              {active === ing.name && (
                <div className="bg-petal border border-bronze p-4 mt-1">
                  <p className="text-xs text-charcoal font-sans leading-relaxed">{ing.description}</p>
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function SocialProof() {
  return (
    <section className="py-24 px-6 lg:px-8 bg-warm">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-14">
          <p className="text-xs tracking-[0.25em] uppercase text-stone font-sans mb-3">Community</p>
          <h2 className="font-display text-4xl lg:text-5xl text-charcoal mb-4">
            Loved by 48,000+ everyday rituals, one community.
          </h2>
        </div>

        {/* Testimonials */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6 mb-16">
          {testimonials.map((t) => (
            <div key={t.id} className="bg-ivory p-6 flex flex-col gap-4">
              <div className="flex items-center gap-1">
                {[1, 2, 3, 4, 5].map((s) => (
                  <svg key={s} width="11" height="11" viewBox="0 0 20 20" fill={s <= t.rating ? "#8CA0C4" : "none"} stroke="#8CA0C4" strokeWidth="1.5">
                    <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.286 3.956a1 1 0 00.95.69h4.162c.969 0 1.371 1.24.588 1.81l-3.37 2.448a1 1 0 00-.364 1.118l1.287 3.957c.3.921-.755 1.688-1.54 1.118L10 15.347l-3.95 2.877c-.784.57-1.838-.197-1.539-1.118l1.287-3.957a1 1 0 00-.364-1.118L2.064 9.383c-.784-.57-.38-1.81.588-1.81h4.162a1 1 0 00.95-.69l1.285-3.956z" />
                  </svg>
                ))}
              </div>
              <p className="text-sm text-charcoal font-sans leading-relaxed flex-1">&ldquo;{t.review}&rdquo;</p>
              <div className="flex items-center gap-3 pt-3 border-t border-linen">
                <img src={t.image} alt={t.name} className="w-9 h-9 rounded-full object-cover bg-warm" />
                <div>
                  <p className="text-xs font-medium text-charcoal font-sans">{t.name}</p>
                  <p className="text-[11px] text-stone font-sans">{t.product}</p>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Gallery */}
        <div className="grid grid-cols-3 lg:grid-cols-6 gap-2">
          {galleryImages.map((url, i) => (
            <div key={i} className="aspect-square overflow-hidden bg-warm">
              <img src={url} alt="Customer ritual" className="w-full h-full object-cover hover:scale-105 transition-transform duration-500 cursor-pointer" />
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function OffersSection({ onNavigate }: { onNavigate: (page: string, p?: undefined, cat?: string) => void }) {
  return (
    <section className="py-24 px-6 lg:px-8 bg-charcoal">
      <div className="max-w-5xl mx-auto flex flex-col lg:flex-row items-center gap-12 lg:gap-20">
        <div className="flex-1 text-center lg:text-left">
          <p className="text-xs tracking-[0.25em] uppercase text-bronze font-sans mb-4">Limited Offer</p>
          <h2 className="font-display text-4xl lg:text-5xl text-ivory mb-6 leading-tight">
            Build Your<br />Everyday Ritual
          </h2>
          <p className="text-stone font-sans mb-8 leading-relaxed">
            Choose any 3 body-care essentials and save on your order. Free shipping included.
          </p>
          <button
            onClick={() => onNavigate("shop", undefined, "body")}
            className="bg-bronze text-ivory px-10 py-4 text-sm tracking-widest uppercase font-sans hover:bg-ivory hover:text-charcoal transition-colors duration-300"
          >
            Shop the Collection
          </button>
        </div>
        <div className="flex gap-4">
          {[
            "https://images.unsplash.com/photo-1706780446649-afca6a1a3b33?w=200&h=280&fit=crop",
            "https://images.unsplash.com/photo-1771832796215-9740b45aa390?w=200&h=280&fit=crop",
            "https://images.unsplash.com/photo-1709551264885-06719a695b4c?w=200&h=280&fit=crop",
          ].map((url, i) => (
            <div
              key={i}
              className="w-28 bg-warm overflow-hidden shrink-0"
              style={{ marginTop: i === 1 ? "2rem" : "0" }}
            >
              <img src={url + "&auto=format"} alt="Body care product" className="w-full h-full object-cover" />
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

interface HomePageProps {
  onNavigate: (page: string, product?: undefined, category?: string) => void;
}

export default function HomePage({ onNavigate }: HomePageProps) {
  return (
    <>
      <Philosophy />
      <Ingredients />
      <SocialProof />
      <OffersSection onNavigate={onNavigate} />
    </>
  );
}
