import { Product } from "../data";

interface ProductCardProps {
  product: Product;
  onView: (product: Product) => void;
  onAddToCart: (product: Product) => void;
  isWishlisted: boolean;
  onWishlist: (id: number) => void;
}

function Stars({ rating }: { rating: number }) {
  return (
    <div className="flex items-center gap-0.5">
      {[1, 2, 3, 4, 5].map((s) => (
        <svg
          key={s}
          width="11"
          height="11"
          viewBox="0 0 20 20"
          fill={s <= Math.round(rating) ? "#8CA0C4" : "none"}
          stroke="#8CA0C4"
          strokeWidth="1.5"
        >
          <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.286 3.956a1 1 0 00.95.69h4.162c.969 0 1.371 1.24.588 1.81l-3.37 2.448a1 1 0 00-.364 1.118l1.287 3.957c.3.921-.755 1.688-1.54 1.118L10 15.347l-3.95 2.877c-.784.57-1.838-.197-1.539-1.118l1.287-3.957a1 1 0 00-.364-1.118L2.064 9.383c-.784-.57-.38-1.81.588-1.81h4.162a1 1 0 00.95-.69l1.285-3.956z" />
        </svg>
      ))}
    </div>
  );
}

export default function ProductCard({
  product,
  onView,
  onAddToCart,
  isWishlisted,
  onWishlist,
}: ProductCardProps) {
  const discount = product.originalPrice
    ? Math.round(((product.originalPrice - product.price) / product.originalPrice) * 100)
    : null;

  return (
    <div className="product-card group relative flex flex-col bg-ivory">
      {/* Image Container */}
      <div
        className="relative overflow-hidden bg-warm aspect-[3/4] cursor-pointer"
        onClick={() => onView(product)}
      >
        <img
          src={product.image}
          alt={product.name}
          className="product-img-zoom w-full h-full object-cover"
        />

        {/* Overlay */}
        <div className="product-overlay absolute inset-0 bg-charcoal/20 flex items-center justify-center">
          <span className="bg-ivory text-charcoal text-xs tracking-widest uppercase px-6 py-3 font-sans">
            View Product
          </span>
        </div>

        {/* Badges */}
        <div className="absolute top-3 left-3 flex flex-col gap-1.5">
          {product.badge && (
            <span className="bg-bronze text-ivory text-[10px] tracking-widest uppercase px-2.5 py-1 font-sans">
              {product.badge}
            </span>
          )}
          {product.isNew && (
            <span className="bg-charcoal text-ivory text-[10px] tracking-widest uppercase px-2.5 py-1 font-sans">
              New
            </span>
          )}
        </div>

        {/* Wishlist */}
        <button
          onClick={(e) => { e.stopPropagation(); onWishlist(product.id); }}
          className="absolute top-3 right-3 w-8 h-8 bg-ivory/80 backdrop-blur-sm flex items-center justify-center hover:bg-ivory transition-colors"
          aria-label={isWishlisted ? "Remove from wishlist" : "Add to wishlist"}
        >
          <svg
            width="15"
            height="15"
            fill={isWishlisted ? "#8CA0C4" : "none"}
            stroke="#8CA0C4"
            strokeWidth="1.5"
            viewBox="0 0 24 24"
          >
            <path strokeLinecap="round" d="M21 8.25c0-2.485-2.099-4.5-4.688-4.5-1.935 0-3.597 1.126-4.312 2.733-.715-1.607-2.377-2.733-4.313-2.733C5.1 3.75 3 5.765 3 8.25c0 7.22 9 12 9 12s9-4.78 9-12z" />
          </svg>
        </button>
      </div>

      {/* Info */}
      <div className="pt-4 pb-2 px-0.5 flex flex-col gap-2 flex-1">
        <div className="flex items-center gap-2">
          <Stars rating={product.rating} />
          <span className="text-[11px] text-stone font-sans">({product.reviewCount})</span>
        </div>

        <button
          onClick={() => onView(product)}
          className="text-left font-sans font-medium text-sm text-charcoal hover:text-bronze transition-colors leading-snug"
        >
          {product.name}
        </button>

        <p className="text-xs text-stone font-sans leading-relaxed line-clamp-1">{product.shortDesc}</p>

        <div className="flex items-center gap-2 mt-1">
          <span className="font-sans font-semibold text-charcoal">₹{product.price}</span>
          {product.originalPrice && (
            <span className="text-stone text-sm font-sans line-through">₹{product.originalPrice}</span>
          )}
          {discount && (
            <span className="text-bronze text-xs font-sans">{discount}% off</span>
          )}
        </div>

        {/* Quick Add */}
        <button
          onClick={() => onAddToCart(product)}
          className="mt-2 w-full border border-charcoal text-charcoal text-xs tracking-widest uppercase py-3 font-sans hover:bg-charcoal hover:text-ivory transition-colors duration-200"
        >
          Quick Add
        </button>
      </div>
    </div>
  );
}
