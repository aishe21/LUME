import { useState } from "react";

interface FooterProps {
  onNavigate: (page: string, product?: undefined, category?: string) => void;
}

export default function Footer({ onNavigate }: FooterProps) {
  const [email, setEmail] = useState("");
  const [subscribed, setSubscribed] = useState(false);

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    if (email) {
      setSubscribed(true);
      setEmail("");
    }
  };

  return (
    <footer className="bg-charcoal text-ivory">
      {/* Newsletter */}
      <div className="border-b border-stone/20 py-16 px-6 lg:px-8">
        <div className="max-w-7xl mx-auto flex flex-col lg:flex-row items-center justify-between gap-8">
          <div>
            <p className="text-xs tracking-[0.25em] uppercase text-bronze font-sans mb-2">Stay Connected</p>
            <h3 className="font-display text-3xl text-ivory">Join our beauty ritual.</h3>
          </div>
          {subscribed ? (
            <p className="text-bronze font-sans text-sm">Thank you for subscribing!</p>
          ) : (
            <form onSubmit={handleSubscribe} className="flex w-full max-w-md gap-3">
              <input
                type="email"
                placeholder="Your email address"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
                className="flex-1 bg-transparent border border-stone/30 px-4 py-3 text-sm font-sans text-ivory placeholder-stone/50 focus:border-bronze transition-colors"
              />
              <button
                type="submit"
                className="bg-bronze text-ivory px-6 py-3 text-xs tracking-widest uppercase font-sans hover:bg-ivory hover:text-charcoal transition-colors shrink-0"
              >
                Subscribe
              </button>
            </form>
          )}
        </div>
      </div>

      {/* Main Footer */}
      <div className="py-16 px-6 lg:px-8">
        <div className="max-w-7xl mx-auto grid grid-cols-2 lg:grid-cols-5 gap-10">
          {/* Brand */}
          <div className="col-span-2 lg:col-span-1">
            <p className="font-display text-2xl tracking-[0.2em] mb-4">
              LUM<span className="text-bronze">É</span>
            </p>
            <p className="text-stone text-xs font-sans leading-relaxed">
              Thoughtfully crafted skincare and body essentials for your everyday ritual.
            </p>
          </div>

          {/* Shop */}
          <div>
            <p className="text-xs uppercase tracking-widest font-sans text-ivory mb-5">Shop</p>
            <ul className="flex flex-col gap-3">
              {[["Skincare", "skincare"], ["Body Care", "body"], ["Soaps", "soaps"], ["Hair Care", "hair"], ["Best Sellers", "all"]].map(([label, cat]) => (
                <li key={label}>
                  <button
                    onClick={() => onNavigate("shop", undefined, cat)}
                    className="text-stone text-xs font-sans hover:text-ivory transition-colors"
                  >
                    {label}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* About */}
          <div>
            <p className="text-xs uppercase tracking-widest font-sans text-ivory mb-5">About</p>
            <ul className="flex flex-col gap-3">
              {["Our Story", "Ingredients", "Contact", "FAQ"].map((item) => (
                <li key={item}>
                  <button className="text-stone text-xs font-sans hover:text-ivory transition-colors">{item}</button>
                </li>
              ))}
            </ul>
          </div>

          {/* Customer Care */}
          <div>
            <p className="text-xs uppercase tracking-widest font-sans text-ivory mb-5">Customer Care</p>
            <ul className="flex flex-col gap-3">
              {["Shipping", "Returns", "Privacy", "Terms"].map((item) => (
                <li key={item}>
                  <button className="text-stone text-xs font-sans hover:text-ivory transition-colors">{item}</button>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact */}
          <div>
            <p className="text-xs uppercase tracking-widest font-sans text-ivory mb-5">Connect</p>
            <ul className="flex flex-col gap-3">
              <li><a href="https://instagram.com/lume.beauty" target="_blank" rel="noreferrer" className="text-stone text-xs font-sans hover:text-ivory transition-colors">@lume.beauty</a></li>
              <li><a href="https://pinterest.com/lumebeauty" target="_blank" rel="noreferrer" className="text-stone text-xs font-sans hover:text-ivory transition-colors">Pinterest</a></li>
              <li><a href="mailto:hello@lumebeauty.in" className="text-stone text-xs font-sans hover:text-ivory transition-colors">hello@lumebeauty.in</a></li>
              <li><p className="text-stone text-xs font-sans">+91 80 4718 2026</p></li>
            </ul>
          </div>
        </div>
      </div>

      {/* Bottom */}
      <div className="border-t border-stone/20 py-5 px-6 lg:px-8">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-2 text-xs text-stone font-sans">
          <p>© 2026 LUMÉ Beauty Pvt. Ltd. All rights reserved.</p>
          <p>Crafted with care in Bengaluru, India.</p>
        </div>
      </div>
    </footer>
  );
}
