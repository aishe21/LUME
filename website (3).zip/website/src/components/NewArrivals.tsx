import { newArrivals, Product } from "../data";
import ProductCard from "./ProductCard";

interface NewArrivalsProps {
  onView: (product: Product) => void;
  onAddToCart: (product: Product) => void;
  wishlist: number[];
  onWishlist: (id: number) => void;
  onNavigate: (page: string) => void;
}

export default function NewArrivals({ onView, onAddToCart, wishlist, onWishlist, onNavigate }: NewArrivalsProps) {
  return (
    <section id="new-arrivals" className="pt-14 pb-24 bg-ivory overflow-hidden scroll-mt-16 lg:scroll-mt-20">
      <div className="px-6 lg:px-8 mb-10">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row sm:items-end sm:justify-between gap-4">
          <div>
            <p className="text-xs tracking-[0.25em] uppercase text-stone font-sans mb-3">Just In</p>
            <h2 className="font-display text-4xl lg:text-5xl text-charcoal">New Arrivals</h2>
          </div>
          <button
            onClick={() => onNavigate("shop")}
            className="text-sm text-bronze hover:text-charcoal transition-colors font-sans tracking-wide underline underline-offset-4 self-start sm:self-auto"
          >
            View all →
          </button>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-6 lg:px-8">
        {/* Mobile: horizontal snap scroll */}
        <div className="snap-x-scroll pb-4 lg:hidden -mx-6 px-6">
          <div className="flex gap-6" style={{ width: "max-content" }}>
            {newArrivals.map((product) => (
              <div key={product.id} className="snap-item w-64 sm:w-72 shrink-0">
                <ProductCard
                  product={product}
                  onView={onView}
                  onAddToCart={onAddToCart}
                  isWishlisted={wishlist.includes(product.id)}
                  onWishlist={onWishlist}
                />
              </div>
            ))}
          </div>
        </div>

        {/* Desktop: grid that fits the window */}
        <div className="hidden lg:grid grid-cols-4 gap-8">
          {newArrivals.slice(0, 4).map((product) => (
            <ProductCard
              key={product.id}
              product={product}
              onView={onView}
              onAddToCart={onAddToCart}
              isWishlisted={wishlist.includes(product.id)}
              onWishlist={onWishlist}
            />
          ))}
        </div>
      </div>
    </section>
  );
}
